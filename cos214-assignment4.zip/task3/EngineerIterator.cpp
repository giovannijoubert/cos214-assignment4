#include "EngineerIterator.h"
#include <iostream>

EngineerIterator::EngineerIterator(){
    
}